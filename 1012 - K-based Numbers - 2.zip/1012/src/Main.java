
import java.math.BigInteger;
import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gladiator
 */
public class Main {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        String N = sc.nextLine();
        String K = sc.nextLine();
        int nInt = Integer.parseInt(N);
        //System.out.println(nInt);
        BigInteger a,b,c;
        BigInteger kMinusOne = new BigInteger(K).subtract(new BigInteger("1"));
        a = new BigInteger("1");
        b = kMinusOne;
        c = a;
        for(int i=1;i<nInt;i++){
            c = a.add(b);
            c = c.multiply(new BigInteger(kMinusOne.toString()));
            a = b;
            b = c;
            //System.out.println(c.toString());
        }
        System.out.println(c.toString());
    }

}
//19140929114881653462476041684116627391559236845580909494492016732196087599513580596508681339397425705393057484060909466165965897483835868175679753976672747715432612675930
//19140929114881653462476041684116627391559236845580909494492016732196087599513580596508681339397425705393057484060909466165965897483835868175679753976672747715432612675930